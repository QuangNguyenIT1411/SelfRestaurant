# Bài 2. Thiết Kế View Kiến Trúc Cài Đặt

## 1. Mô tả chung

Ở góc nhìn cài đặt, hệ thống được xem xét dưới khía cạnh tổ chức mã nguồn, package và thành phần triển khai trong solution. Project hiện tại tổ chức theo hướng microservice, trong đó gateway MVC đóng vai trò điều phối giao diện và gọi các API phía sau.

File biểu đồ:

- `Package_Diagram.txt`
- `Component_Diagram.txt`

## 2. Giới thiệu các package

### 2.1. Package Gateway MVC

Đây là package trình bày của hệ thống, chịu trách nhiệm render giao diện web, quản lý session và điều phối request từ người dùng cuối.

### 2.2. Package Gateway Areas.Admin

Nhóm package dành cho chức năng quản trị: danh mục, món ăn, nguyên liệu, bàn, khách hàng, nhân viên và báo cáo.

### 2.3. Package Gateway Areas.Staff

Nhóm package dành cho đầu bếp, thu ngân, quản lý và đăng nhập nhân viên.

### 2.4. Package Gateway.Services

Chứa các API client như `CatalogClient`, `OrdersClient`, `CustomersClient`, `IdentityClient`, `BillingClient`. Đây là lớp trung gian để Gateway gọi xuống các microservice.

### 2.5. Package Gateway.Infrastructure

Chứa các thành phần hạ tầng như `CorrelationIdHandler`, `SessionKeys`, `StaffAuthorizeAttribute`. Package này hỗ trợ logging, session và kiểm soát truy cập.

### 2.6. Package Services.Catalog.Api

Microservice quản lý dữ liệu danh mục, chi nhánh, bàn ăn, thực đơn, món ăn và nguyên liệu.

### 2.7. Package Services.Orders.Api

Microservice xử lý đặt món, quản lý trạng thái đơn hàng, bếp, xác nhận nhận món và thống kê đơn hàng.

### 2.8. Package Services.Customers.Api

Microservice xử lý hồ sơ khách hàng, lịch sử đơn hàng, quản trị khách hàng và một phần chức năng định danh tương thích.

### 2.9. Package Services.Identity.Api

Microservice định danh cho khách hàng và nhân viên: đăng nhập, đăng ký, quên mật khẩu, đổi mật khẩu, quản lý tài khoản nhân viên.

### 2.10. Package Services.Billing.Api

Microservice xử lý thanh toán, lập hóa đơn, báo cáo thu ngân và tổng hợp giao dịch cuối ngày.

### 2.11. Package Shared.Database

Thư viện dùng chung chứa `RestaurantDbContext`, entity classes và bootstrap logic cho cơ sở dữ liệu SQL Server.

## 3. Giới thiệu các component

### 3.1. Web Client

Trình duyệt của khách hàng, đầu bếp, thu ngân, quản trị viên. Thành phần này chỉ giao tiếp trực tiếp với Gateway MVC.

### 3.2. Gateway MVC

Thành phần giao diện và điều phối. Gateway nhận request từ người dùng, quản lý session và gọi các service client để truy xuất hoặc cập nhật dữ liệu.

### 3.3. CatalogClient

Component tích hợp của Gateway để làm việc với Catalog API, phục vụ dữ liệu chi nhánh, bàn, thực đơn, món ăn, nguyên liệu.

### 3.4. OrdersClient

Component tích hợp của Gateway để xử lý đặt món, cập nhật giỏ hàng, gửi bếp, xác nhận nhận món và thao tác nghiệp vụ bếp.

### 3.5. CustomersClient

Component tích hợp của Gateway để truy cập hồ sơ khách hàng, lịch sử đơn hàng và quản trị khách hàng.

### 3.6. IdentityClient

Component tích hợp của Gateway để xử lý đăng nhập, đăng ký, quên mật khẩu và quản lý tài khoản nhân viên.

### 3.7. BillingClient

Component tích hợp của Gateway để truy cập nghiệp vụ thu ngân, hóa đơn và báo cáo thanh toán.

### 3.8. Catalog API

Microservice chuyên trách cho miền dữ liệu thực đơn và bàn ăn. Đây là nguồn dữ liệu nền cho giao diện khách hàng và quản trị danh mục.

### 3.9. Orders API

Microservice cốt lõi của quy trình phục vụ. Thành phần này chịu trách nhiệm duy trì đơn hàng theo bàn và điều phối luồng bếp.

### 3.10. Customers API

Microservice quản lý dữ liệu khách hàng và các chức năng liên quan tới hồ sơ, lịch sử, loyalty.

### 3.11. Identity API

Microservice định danh và tài khoản. Thành phần này xử lý xác thực và các nghiệp vụ bảo mật mức ứng dụng.

### 3.12. Billing API

Microservice thanh toán và hóa đơn. Thành phần này tạo hóa đơn, xử lý chiết khấu, điểm thưởng và báo cáo thu ngân.

### 3.13. Shared Database Library

Thành phần thư viện chung giúp các service dùng chung mô hình dữ liệu, context và cấu hình cơ sở dữ liệu.

### 3.14. SQL Server Database

Kho lưu trữ dữ liệu trung tâm của hệ thống. Trong phiên bản hiện tại, các microservice cùng dùng chung một cơ sở dữ liệu vật lý.

## 4. Nhận xét cho góc nhìn cài đặt

Góc nhìn cài đặt cho thấy project được tổ chức khá rõ theo tầng:

- Tầng giao diện và orchestration ở Gateway
- Tầng microservice theo miền nghiệp vụ
- Tầng dữ liệu dùng chung

Điểm đáng chú ý là solution đang theo mô hình microservice ở mức triển khai ứng dụng, nhưng dữ liệu vẫn dùng chung một `DbContext` và một SQL Server. Đây là một thiết kế thực dụng, phù hợp với đồ án học phần và thuận tiện cho triển khai/demo.
