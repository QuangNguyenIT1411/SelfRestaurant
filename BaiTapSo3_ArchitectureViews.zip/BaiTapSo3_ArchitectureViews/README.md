# Bài Tập Trên Lớp Số 3

Thư mục này chứa bài làm dựa trên:

- `Bai tap tren lop so 3.pdf`
- `Chuong 4_p1_Cac goc nhin kien truc_Architecture Views.pdf`
- `Chuong 4_p2_Tai lieu hoa kien truc_Documenting.pdf`
- Mã nguồn project `SelfRestaurant.Microservices.sln`

Tổ chức file:

- `Bai1_Logical_View.md`
- `Bai2_Implementation_View.md`
- `Bai3_Process_View.md`
- `Bai4_Deployment_View.md`

Các biểu đồ Mermaid được tách riêng, mỗi biểu đồ là một file `.txt`:

- `UseCase_Diagram.txt`
- `Class_Diagram.txt`
- `Package_Diagram.txt`
- `Component_Diagram.txt`
- `Activity_Customer_Order.txt`
- `Activity_Chef_Fulfillment.txt`
- `Activity_Cashier_QR_Payment.txt`
- `Deployment_Diagram.txt`

Lưu ý:

- Nội dung được xây dựng theo thực tế project microservice hiện tại.
- Mermaid được dùng làm mã nguồn biểu đồ; khi nộp chính thức có thể render lại thành hình UML để chèn vào Word/PDF.
