# Bài 1. Thiết Kế View Kiến Trúc Logic

## 1. Mô tả chung

Hệ thống được phân tích là phần mềm quản lý nhà hàng tự phục vụ trên nền tảng web, được hiện thực theo kiến trúc microservice. Ở góc nhìn logic, trọng tâm là xác định các tác nhân nghiệp vụ, các use case chính và các lớp miền nghiệp vụ cốt lõi tạo nên hành vi của hệ thống.

Các tác nhân chính:

- Khách hàng
- Đầu bếp
- Thu ngân
- Quản trị viên

File biểu đồ:

- `UseCase_Diagram.txt`
- `Class_Diagram.txt`

## 2. Giới thiệu Use Case tổng thể

### 2.1. Chọn chi nhánh và bàn

Khách hàng duyệt danh sách chi nhánh, xem bàn trống và chọn bàn phù hợp trước khi thao tác đặt món.

### 2.2. Đăng ký tài khoản khách hàng

Khách mới tạo tài khoản để lưu thông tin cá nhân, tích điểm và theo dõi lịch sử đơn hàng.

### 2.3. Đăng nhập khách hàng

Khách hàng đăng nhập để sử dụng các chức năng cá nhân hóa như tích điểm, đổi điểm và quay lại bàn đang sử dụng.

### 2.4. Xem thực đơn

Khách hàng duyệt thực đơn theo danh mục, xem thông tin món ăn, giá bán, hình ảnh và trạng thái món nổi bật.

### 2.5. Thêm món vào đơn

Khách hàng thêm món, thay đổi số lượng, thêm ghi chú món và gửi đơn xuống bếp.

### 2.6. Xác nhận nhận món

Sau khi bếp hoàn tất món ăn, khách hàng xác nhận đã nhận món để đồng bộ trạng thái đơn hàng với bếp.

### 2.7. Thanh toán đơn hàng

Khách hàng gửi yêu cầu thanh toán; thu ngân tiếp nhận, tính tiền, áp dụng điểm và hoàn tất hóa đơn.

### 2.8. Theo dõi điểm tích lũy

Khách hàng xem điểm hiện tại, quy tắc quy đổi điểm và điểm cộng thêm sau mỗi giao dịch.

### 2.9. Xử lý đơn tại bếp

Đầu bếp xem danh sách đơn chờ, bắt đầu chế biến, cập nhật món đã sẵn sàng và theo dõi lịch sử xử lý.

### 2.10. Thu ngân xử lý hóa đơn

Thu ngân xem danh sách bàn có khách, mở hóa đơn chờ thanh toán, áp dụng khuyến mãi theo điểm và xác nhận phương thức thanh toán QR hoặc tiền mặt.

### 2.11. Quản trị thực đơn và nguyên liệu

Quản trị viên quản lý danh mục, món ăn, nguyên liệu, định lượng nguyên liệu theo món và bàn ăn.

### 2.12. Quản trị người dùng và báo cáo

Quản trị viên quản lý khách hàng, nhân viên, vai trò và theo dõi báo cáo doanh thu, món bán chạy, thống kê vận hành.

## 3. Giới thiệu các lớp trong biểu đồ lớp

### 3.1. Customers

Lớp biểu diễn khách hàng của hệ thống. Đối tượng này lưu thông tin hồ sơ, tài khoản đăng nhập, điểm thưởng và liên kết với đơn hàng, hóa đơn, thanh toán.

### 3.2. Employees

Lớp biểu diễn nhân viên. Đối tượng này bao gồm đầu bếp, thu ngân, quản trị viên và liên kết tới chi nhánh, vai trò, hóa đơn và đơn hàng.

### 3.3. Branches

Lớp đại diện cho chi nhánh nhà hàng. Mỗi chi nhánh quản lý nhân viên và các bàn ăn thuộc phạm vi hoạt động của mình.

### 3.4. DiningTables

Lớp quản lý thông tin bàn ăn, số ghế, trạng thái bàn, mã QR và đơn hàng hiện tại tại bàn.

### 3.5. Categories

Lớp biểu diễn danh mục món ăn như món chính, món phụ, tráng miệng, đồ uống.

### 3.6. Dishes

Lớp biểu diễn món ăn trong thực đơn. Mỗi món có giá, hình ảnh, mô tả, đơn vị tính, trạng thái hoạt động và liên kết tới danh mục, nguyên liệu và chi tiết đặt món.

### 3.7. Ingredients

Lớp biểu diễn nguyên liệu. Hệ thống dùng lớp này để quản lý tồn kho và định lượng nguyên liệu gắn với từng món.

### 3.8. Orders

Lớp trung tâm của miền nghiệp vụ đặt món. Orders liên kết khách hàng, bàn ăn, trạng thái xử lý, nhân viên thu ngân và các dòng món trong đơn.

### 3.9. OrderItems

Lớp biểu diễn từng dòng món trong đơn hàng. Mỗi dòng lưu số lượng, đơn giá, thành tiền và ghi chú riêng cho món.

### 3.10. Bills

Lớp hóa đơn được tạo khi thu ngân hoàn tất thanh toán. Hóa đơn lưu tổng tiền, giảm giá, giảm theo điểm, phương thức thanh toán và thông tin khách hàng/nhân viên.

### 3.11. Payments

Lớp biểu diễn giao dịch thanh toán. Đây là thực thể kỹ thuật dùng để theo dõi số tiền, phương thức thanh toán và trạng thái giao dịch.

### 3.12. OrderStatus

Lớp danh mục trạng thái đơn hàng như pending, preparing, ready, completed, cancelled.

### 3.13. TableStatus

Lớp danh mục trạng thái bàn như available, occupied hoặc các trạng thái vận hành khác.

### 3.14. PaymentMethod

Lớp danh mục phương thức thanh toán như cash, qr, transfer.

### 3.15. PaymentStatus

Lớp danh mục trạng thái giao dịch thanh toán như pending, paid hoặc failed.

## 4. Nhận xét cho góc nhìn logic

Góc nhìn logic của hệ thống cho thấy project được xoay quanh bốn cụm nghiệp vụ chính:

- Phục vụ khách hàng tại bàn
- Chế biến món tại bếp
- Thanh toán và tích điểm
- Quản trị danh mục và vận hành

Mặc dù hệ thống triển khai theo microservice, ở mức logic các thực thể nghiệp vụ vẫn giữ cấu trúc khá rõ ràng, thuận lợi cho việc tài liệu hóa, kiểm thử và mở rộng chức năng.
