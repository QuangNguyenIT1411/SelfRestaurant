# Bài 3. Thiết Kế View Kiến Trúc Tiến Trình

## 1. Mô tả chung

Góc nhìn tiến trình tập trung mô tả các quy trình nghiệp vụ chính của hệ thống và cách các thành phần phối hợp trong thời gian chạy. Với project hiện tại, ba quy trình trọng tâm nhất là:

- Khách hàng chọn bàn và đặt món
- Bếp xử lý đơn và khách xác nhận nhận món
- Thu ngân thanh toán QR và cập nhật điểm thưởng

File biểu đồ:

- `Activity_Customer_Order.txt`
- `Activity_Chef_Fulfillment.txt`
- `Activity_Cashier_QR_Payment.txt`

## 2. Giải thích biểu đồ hoạt động 1: Khách hàng chọn bàn và đặt món

Quy trình bắt đầu khi khách hàng truy cập trang chủ, chọn chi nhánh, chọn bàn và mở thực đơn. Sau đó khách xem menu, thêm món vào đơn, có thể chỉnh số lượng hoặc ghi chú món. Khi khách xác nhận gửi đơn, Gateway chuyển yêu cầu xuống Orders API để tạo hoặc cập nhật đơn hàng, đồng thời đổi trạng thái bàn sang đang phục vụ.

Ý nghĩa kiến trúc của quy trình này:

- Gateway MVC giữ vai trò điều phối giao diện.
- Catalog API cung cấp dữ liệu menu và bàn.
- Orders API quản lý trạng thái đơn hàng theo thời gian thực.

## 3. Giải thích biểu đồ hoạt động 2: Bếp xử lý món và khách xác nhận nhận món

Sau khi đơn được gửi bếp, đầu bếp xem danh sách đơn chờ, bắt đầu chế biến, rồi cập nhật trạng thái sang `READY`. Khi trạng thái này xuất hiện, khách hàng nhận được thông tin món đã sẵn sàng và xác nhận đã nhận món. Sau xác nhận, trạng thái đơn được cập nhật để đơn biến mất khỏi danh sách món sẵn sàng tại bếp.

Ý nghĩa kiến trúc của quy trình này:

- Orders API là trung tâm đồng bộ trạng thái giữa bếp và khách.
- Gateway MVC hiển thị trạng thái ở hai giao diện khác nhau nhưng cùng dùng một nguồn trạng thái.
- Quy trình làm rõ tính tương tác giữa actor và tính nhất quán nghiệp vụ.

## 4. Giải thích biểu đồ hoạt động 3: Thu ngân thanh toán QR và cộng điểm

Khi khách yêu cầu thanh toán, thu ngân mở hóa đơn đang chờ, xem thông tin khách hàng, điểm hiện tại và số điểm có thể dùng để giảm giá. Thu ngân chọn phương thức QR, hệ thống tính tổng tiền cuối cùng, áp dụng giảm tối đa theo điểm, tạo bill, cập nhật điểm thưởng và giải phóng bàn. Sau thanh toán, giỏ món và trạng thái quay lại bàn của khách được xóa.

Ý nghĩa kiến trúc của quy trình này:

- Billing API xử lý nghiệp vụ tài chính và loyalty.
- Customers/Identity service hỗ trợ dữ liệu tài khoản, hồ sơ và điểm.
- Orders API và Catalog/Orders data cùng phối hợp để giải phóng bàn sau thanh toán.

## 5. Nhận xét cho góc nhìn tiến trình

Ba quy trình trên phản ánh rõ các đặc tính vận hành của hệ thống:

- Có sự phối hợp giữa nhiều vai trò người dùng
- Có trạng thái biến đổi theo thời gian thực
- Có ràng buộc đồng bộ dữ liệu giữa đơn hàng, bàn ăn, thanh toán và điểm thưởng

Vì vậy Process View là góc nhìn quan trọng để kiểm chứng tính đúng đắn của giải pháp microservice này.
