# Bài 4. Thiết Kế View Kiến Trúc Triển Khai / Vật Lý

## 1. Mô tả chung

Góc nhìn triển khai mô tả cách các thành phần phần mềm được đặt trên các node hạ tầng khi hệ thống vận hành. Với project hiện tại, hệ thống được triển khai theo mô hình nhiều tiến trình ứng dụng .NET tách rời, giao tiếp qua HTTP nội bộ và dùng chung SQL Server.

File biểu đồ:

- `Deployment_Diagram.txt`

## 2. Giới thiệu các thành phần triển khai

### 2.1. Thiết bị khách hàng

Node này là trình duyệt web trên điện thoại, tablet hoặc máy tính của khách hàng. Người dùng sử dụng node này để chọn bàn, gọi món, theo dõi món và xem điểm thưởng.

### 2.2. Thiết bị nhân viên bếp

Node này là trình duyệt hoặc máy tính ở khu vực bếp, dùng để xem danh sách đơn chờ, cập nhật trạng thái món và xác nhận quy trình phục vụ.

### 2.3. Thiết bị thu ngân / quản trị

Node này là trình duyệt hoặc máy tính của thu ngân và quản trị viên, dùng để thanh toán, in hóa đơn, quản lý dữ liệu và xem báo cáo.

### 2.4. Web Server chạy Gateway MVC

Node này triển khai `SelfRestaurant.Gateway.Mvc`. Đây là điểm vào duy nhất của giao diện web và chịu trách nhiệm giao tiếp với các microservice.

### 2.5. Application Node: Catalog API

Node chạy `SelfRestaurant.Catalog.Api`, phục vụ dữ liệu chi nhánh, bàn, thực đơn, danh mục, món ăn, nguyên liệu.

### 2.6. Application Node: Orders API

Node chạy `SelfRestaurant.Orders.Api`, xử lý vòng đời đơn hàng, trạng thái bếp, xác nhận nhận món và thống kê đơn.

### 2.7. Application Node: Customers API

Node chạy `SelfRestaurant.Customers.Api`, phụ trách hồ sơ khách hàng, lịch sử đơn hàng, thông tin loyalty và một số API tương thích liên quan tới tài khoản.

### 2.8. Application Node: Identity API

Node chạy `SelfRestaurant.Identity.Api`, phụ trách xác thực khách hàng, xác thực nhân viên, đổi/quên/reset mật khẩu và quản lý tài khoản.

### 2.9. Application Node: Billing API

Node chạy `SelfRestaurant.Billing.Api`, xử lý checkout, tạo bill, ghi nhận thanh toán và tạo báo cáo thu ngân.

### 2.10. Database Server: SQL Server

Node dữ liệu lưu toàn bộ bảng nghiệp vụ như khách hàng, món ăn, bàn ăn, đơn hàng, hóa đơn, thanh toán, nguyên liệu, vai trò nhân viên.

### 2.11. Mail Server / SMTP

Node ngoài hệ thống được dùng khi gửi email quên mật khẩu hoặc reset mật khẩu cho khách hàng/nhân viên.

## 3. Nhận xét cho góc nhìn triển khai

Deployment View cho thấy hệ thống đang đi theo hướng tách biệt tiến trình ứng dụng, thuận lợi cho:

- Mở rộng từng service độc lập
- Giám sát lỗi theo từng miền nghiệp vụ
- Bảo trì và thay đổi service mà không ảnh hưởng toàn bộ giao diện

Tuy nhiên, hệ thống vẫn dùng chung một SQL Server, nên tính độc lập dữ liệu giữa các service chưa hoàn toàn triệt để. Đây là điểm có thể nêu thêm trong phần đánh giá kiến trúc nếu cần.
